﻿using System.Collections;
using System;
using System.IO;
using UnityEngine;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public class parseJsonData : MonoBehaviour {
    string path;
    string textString;
    char[] delChars = { ' ', ',', ':', '\t' };
    Regex parts = new Regex(@"^.\d+");

    // Use this for initialization
    void Start () {
        path = Application.streamingAssetsPath + "/abortion.json";
        textString = File.ReadAllText(path);

        string[] words = textString.Split(delChars);

        foreach (var word in words)
        {
            Match match = parts.Match(word);
            if (match.Success)
            {
                if (word.StartsWith("T"))
                    System.Console.WriteLine(word);
                else if (word.StartsWith("R"))
                    System.Console.WriteLine(word);
                else if (word.StartsWith("A"))
                    System.Console.WriteLine(word);
            }
        }


    }
	
}


