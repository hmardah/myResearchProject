﻿
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using CodeMonkey.Utils;
//using SimpleJSON;

public class WindowGraph : MonoBehaviour {
   // private Sprite circleScripte;
    private RectTransform GraphContainer;
    private void Awake()
    {
        GraphContainer = transform.Find("GraphContainer").GetComponent<RectTransform>();

        //List<int> valueList = new List<int> { Random.Range(10, 200) };
        // List<int> valueList = new List<int> {90,60,50,15,10,10,5,6 };
        //  ShowGraph(valueList);
        CreateCircle(new Vector3(0f, 0f, 0f));
    }

    private void CreateCircle(Vector3 anchoredPosition)
    {
        GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        gameObject.transform.SetParent(GraphContainer,false);
        gameObject.AddComponent<Rigidbody>() ;
        gameObject.transform.position = new Vector3(0f, 2f, -7f);
       
        //return gameObject;
    }

 
  
}
